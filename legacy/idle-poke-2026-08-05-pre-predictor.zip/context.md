# Context: 空闲主动对话插件（idle-poke）

## 目标

用定时器实现"伪主动对话"：用户静默 N 秒后，插件注入一条 synthetic 消息让模型主动搭话。零安装/零编译/零运行时依赖，Bun 原生执行 TS。

## 现状摘要（2026-08-04）

- 插件已实现并可用，跨会话漏洞已修复，3 处修复均已落盘。
- **搭话跟随用户当前代理**（plan/build 等），已落盘。
- 运行时搭话状态：当前为**关闭**（用户用标记关的），重启后回默认 `enabled: true`。
- 文件结构：**保持现状**（评审后决定，不迁移）。

## 文件结构

| 路径 | 说明 |
| --- | --- |
| `.opencode/plugins/idle-poke.ts` | 插件本体（命名导出 `IdlePokePlugin: Plugin`） |
| `.opencode/idle-poke.json` | 配置（严格 JSON，无注释；A+C：代码默认值 + 可选 JSON 覆盖） |
| `.opencode/idle-poke-config.md` | 配置/标记/日志说明文档 |
| `.opencode/logs/idle-poke.log` | 运行日志（>10MB 整体删除重建） |
| `.opencode/.gitignore` | 含 `node_modules`、`logs/` 等 |

## 开发历程

### 1. 构思与调研（早期对话）

- 用户提出：定时器实现伪主动对话——用户短时间不说话时发提示让模型主动搭话。
- 方案：监听用户消息重置定时器，超时注入 synthetic 提示。
- 调研结论：**无现成插件精确实现**。`opencode-auto-continue`/`nudge`/`auto-force-resume` 属"让 agent 继续干活"类（检测 `session.idle` 发 continue）；`opencode-clippy` 走桌面气泡，不注入对话。
- 早期 API 概念为 `ctx.session.synthetic()` + `event.subscribe`；最终实现改用 `client.session.prompt` + `synthetic: true` part。

### 2. v1 实现

- 完整实现空闲检测 + synthetic 注入 + 运行时标记协议。
- 标记协议（对话中让模型回复单独一行）：`〔主动搭话已关闭〕`、`〔主动搭话已开启〕`、`〔提醒间隔=N单位〕`（5s~24h 钳制）。
- 搭话模板含"本次请勿读取/修改任何文件、勿执行命令或工具"的建议性约束（仅约束当次回复）。
- 已实际验证：收到合成搭话；标记开关可用。

### 3. 日志迭代

- 独立文件日志（**不调 `client.app.log`**，用户明确选择）。
- 级别 `info`；`debug` 点保留在代码中但被 `LOG_LEVELS` 过滤。
- 保留 `logging.enabled` 开关；日志路径相对项目根解析。
- **放弃 jsonc** → 严格 JSON + 独立 md 文档（避免改 TS 解析逻辑）。
- 10MB 上限：写前 `stat` 检查，超过整体删除重建。
- `.gitignore` 追加 `logs/`。

### 4. 跨会话漏洞修复（已落盘，3 处）

- 问题：A 的挂起定时器在切到 B 后仍会向 A 搭话。
- 修复 1：`poke` 发送前校验 `sessionID === lastActive`，否则丢弃并记 `stale poke skipped`。
- 修复 2：`chat.message` 时清掉除本会话外所有会话的定时器。
- 修复 3：`experimental.chat.system.transform` 改用 `ensure(sessionID)` 兜底（避免新会话首轮漏塞协议）。
- 已审查：无语法/逻辑错误。已接受风险：切换瞬间竞态（可能落一条）、`output.system` 未定义风险、`lastActive` 不随 `session.deleted` 清理。

### 5. "切回即计时"功能（已放弃）

- 目标：切回 A 不打字也立即挂定时器。
- 调研：SDK 含 `tui.session.select` 事件（1.18.4 二进制确认含字符串，但实际发射行为未验证）。
- 曾设计 `activate`/`armTimer` 重构；确认 `enabled`/`delayMs` 为会话持久状态，`activate` 不覆盖（切回不会复活已关闭的搭话、不会把 30s 重置为 60s）。
- **结论：放弃**。理由：依赖版本事件实现，不稳定；需引入 busy 标志等复杂度；"切回后发消息被动重新计时"可接受。

### 6. 文件结构评审（决定保持现状）

- `.opencode/plugins/` 是官方标准（自动发现，`plugin/` 或 `plugins/` 均可）。
- `.opencode/package.json` + `node_modules` 是本地插件依赖的标准做法（启动时 `bun install`）。
- 独立 JSON 配置**非官方但务实**（官方 `plugin` 数组 options 通道有双加载风险）。
- `docs/` 文件夹**非 opencode 惯例**（npm 生态才用根目录 `README.md`）。
- 注意：自动发现是否递归未确认，ts 文件勿放入子文件夹。

### 7. 搭话跟随用户当前代理（已落盘，3 处改动）

- 问题：搭话始终用默认 `build` 代理，即使用户在 `plan` 会话中，导致搭话触发文件读写（违反模板约束）。
- 目标：搭话代理镜像用户在该会话最后一句消息所用的代理（`plan`→搭话用 `plan`，`build`→搭话用 `build`）。
- SDK 确认：`client.session.prompt` 的 `body.agent?: string`（`.opencode/node_modules/@opencode-ai/sdk/dist/gen/types.gen.d.ts:2251`）可显式指定代理。
- 改动 1：`SessionState` 新增 `agent?: string` 字段。
- 改动 2：`chat.message` 钩子内 `if (msg.agent) s.agent = msg.agent`（synthetic 搭话已在早退处跳过，不会污染 `s.agent`）。
- 改动 3：`poke` 中 `body` 展开 `...(s.agent ? { agent: s.agent } : {})`（仅当存在时传）。
- 配置文档同步更新：在 `idle-poke-config.md` 中对 `messageTemplate` 的"勿读写文件"段落补充说明——该提示作为双重保险保留，用户可按需修改或移除。
- 已审查：类型兼容（`msg.agent` 为 `string | undefined`，`body.agent` 为 `string`）；synthetic 早退保护；`SessionState` 逐会话隔离；重启后内存态清空（无持久化）。
- 已接受风险：极端版本 opencode 忽略 `agent` 字段则回退原行为；`msg.agent` 为 `undefined` 时回退默认代理。

### 8. 设计决策记录（已确认）

#### 会话隔离
- **开关与间隔**：`enabled` 和 `delayMs` 均存储在 `SessionState` 中，各会话独立，互不影响。
- **新建会话**：`ensure(sessionID)` 创建新 `SessionState`，继承 `config.enabled` 和 `config.idleMs` 默认值，不受其他会话影响。
- **持久化**：内存态，重启 opencode 后所有会话恢复默认。

#### 外部编辑器行为
- **问题**：用户在外部编辑器（如 vim）输入时，opencode 计时器继续运行，可能触发搭话。
- **决策**：保持当前行为（计时器继续运行）。
- **理由**：搭话注入 TUI 对话，不会打断外部编辑器进程；用户可手动调整间隔（`〔提醒间隔=5分钟〕`）或关闭搭话。
- **技术限制**：opencode 无法可靠识别"外部编辑器活跃"（`vim` 是独立进程，仅能感知文件变化，无法区分用户输入与自动保存）。

#### 标签页切换行为
- **问题**：从 A 切到 B 但不在 B 打字，A 的计时器是否继续？
- **决策**：保持当前行为（计时器继续）。
- **理由**：切换标签页不等于"放弃 A"，用户可能只是瞟一眼 B 或误切。计时器仅在 B 真正收到消息时清除（`chat.message` 钩子），符合"实际切换上下文"语义。
- **验证**：A 发消息 → 切 B → B 打字 → A 计时器清除；A 发消息 → 切 B → 不打字 → A 计时器继续。

#### 外部编辑器与标签页切换的综合
- **场景**：用户在 A 发消息 → 切 B（vim 工作） → A 计时器继续 → 60s 后搭话触发。
- **接受度**：用户可手动调整间隔避免频繁搭话，无需技术干预。

#### 模型（LLM）选择
- **问题**：搭话时未传 `model`，opencode 使用什么模型？
- **调研来源**：opencode 源码 `packages/opencode/src/session/prompt.ts`（`createUserMessage` 函数）。
- **选择优先级**（从高到低）：
  1. `input.model`：请求中显式指定的模型
  2. `agent.model`：Agent 配置的默认模型
  3. `lastModel(sessionID)`：该会话最后一条用户消息使用的模型
  4. `Provider.defaultModel()`：Provider 的全局默认模型
- **当前插件行为**：只传 `agent`，不传 `model` → opencode 自动沿用会话最后使用的模型。
- **结论**：无需额外追踪 `model`，当前实现已满足需求。

### 9. 重启通知（已落盘，3 处改动）

- 问题：插件重启后，LLM 从对话历史推断搭话状态（可能与实际不符），导致误判。
- 目标：在 system prompt 中注入重启通知，告知 LLM 当前默认状态，避免被旧标记干扰。
- 改动 1：`SessionState` 新增 `dirty?: boolean`（用户是否改过搭话设置）和 `notificationInjected?: boolean`（通知是否已注入）。
- 改动 2：`text.complete` 钩子中，检测到任何标记（`hasDisable`/`hasEnable`/间隔匹配）时设 `dirty = true`。
- 改动 3：`transform` 钩子中，当 `!dirty && !notificationInjected` 时注入重启通知（动态读取 `config.enabled` 和 `config.idleMs`），并设 `notificationInjected = true`。
- 已审查：`dirty` 随 `SessionState` 逐会话隔离，重启后重置；通知仅注入一次，不污染对话历史；模板字符串语法合法。
- 已接受风险：长对话中 LLM 可能"忘记"通知（可接受，最坏情况触发标记后用户手动调整）。

## 关键实现细节

- `export const IdlePokePlugin: Plugin = async (input) => {...}`，Bun 直接执行 TS（剥类型，**无 tsc/typecheck**）。
- `loadConfig()`：`DEFAULTS` + `idle-poke.json` 深合并，无效字段回退默认；失败记 warn 日志。
- 每会话状态 `SessionState`：`enabled`（继承 `config.enabled`）、`delayMs`（继承 `config.idleMs`）、`engaged`、`pendingPoke`、`timer`、`agent`（跟随用户最后使用的代理）、`dirty`（用户是否改过搭话设置）、`notificationInjected`（重启通知是否已注入）。
- `onIdle`：仅 `sessionID === lastActive` + `requireEngagement&&engaged` + `enabled` + `!pendingPoke` 才挂定时器。
- `poke`：`lastActive` 守卫 → `pendingPoke=true`（同步，早于 await）→ `client.session.prompt({path:{id}, body:{parts:[{type:"text",text,synthetic:true}], agent: s.agent}})`；成功后 `pendingPoke` 保持 true 直到真实用户消息重置（每轮最多一条）。
- `chat.message`：跳过 synthetic → 记录 `s.agent`（来自 `msg.agent`，仅真实用户消息）→ `activate` 语义（engaged=true、pendingPoke=false、lastActive 更新、清本会话+其他会话定时器）。
- `transform`：`!dirty && !notificationInjected` 时注入重启通知（动态读取 config），并设 `notificationInjected = true`；始终追加 `protocol`。
- 标记检测：`experimental.text.complete` 扫**前 5 行**（`.slice(0,5)`）、整行 trim 相等；disable 优先于 enable。
- 间隔正则：`/^〔提醒间隔\s*[=＝：:]\s*(\d+(?:\.\d+)?)\s*(秒|分钟|小时)?〕$/`，本地换算毫秒，钳制 `MIN_DELAY_MS=5000` ~ `MAX_DELAY_MS=86400000`，范围外忽略。
- 日志：串行 promise 队列（`mkdir`+`stat`+`rm`+`appendFile`），异常吞掉；`stat` 失败跳过检查直接追加。

## 默认配置（`.opencode/idle-poke.json`）

`idleMs: 60000`、`requireEngagement: true`、`enabled: true`、`messageTemplate`（含"本次"勿读写段）、`enableMarker: 〔主动搭话已开启〕`、`disableMarker: 〔主动搭话已关闭〕`、`logging: {enabled: true, level: "info", file: ".opencode/logs/idle-poke.log"}`。

## 已知限制 / 已接受风险

- 整行严格匹配可能漏检；标记只扫前 5 行（前言 >5 行则失效）。
- "勿读写文件"为建议性约束（双重保险，agent 跟随已从工具层面限制）。
- 60s 边界竞态：切换瞬间可能落一条搭话。
- `dispose` 不 flush 日志队列（退出丢最后 1-2 条）。
- `lastActive` 不随 `session.deleted` 清理（无害）。
- 标记开关是运行时内存态，重启回默认开启。
- "当前会话"以最近一次用户消息为准（无标签页可见事件）。
- 日志默认 `info`，看 debug 点需临时改 `logging.level: "debug"`。

## 验证流程（跨会话修复）

1. 重启 opencode。
2. A 发消息 → 等回复结束（idle 挂定时器）→ 静默 60s → 正常搭话（仅当次回复，不读写文件）。
3. 切 B 发消息 → 等 60s+ → A 不应响；查 log 应有 `timer cleared (session switched)` 或 `stale poke skipped`。
4. 回 A 发消息 → A 重新计时，搭话恢复。
5. 标记回归：`〔提醒间隔=5分钟〕` 生效、`〔关闭〕`/`〔开启〕` 正常。

## 验证流程（搭话跟随代理）

1. 切到 `plan` 代理，发消息 → 等回复结束 → 静默 60s。
2. 搭话应以 `plan` 风格回复（给方案/问问题，不读写文件）。
3. 查 log（`debug` 级）应有 `agent: "plan"`。
4. 在 `build` 会话重复，搭话回归 `build` 行为。

## 对话固定响应规则

用户表示停止主动搭话 → 回复中单独一行写 `〔主动搭话已关闭〕`；恢复 → `〔主动搭话已开启〕`；调间隔 → `〔提醒间隔=N单位〕`（N 数字，单位 秒/分钟/小时，缺省秒）。然后正常回复。
