# opencode-idle-poke Plugin Configuration

Config file: `~/.config/opencode/opencode-idle-poke.json` (strict JSON, no comments; defaults are used when the file is missing or unparsable)

| Field | Type | Default | Description |
| --- | --- | --- | --- |
| `idleMs` | number | `60000` | Idle threshold (ms). Poking triggers after the user has been silent this long |
| `requireEngagement` | boolean | `true` | Require at least one real user message before idle detection starts for a session |
| `enabled` | boolean | `true` | Default on/off state on plugin startup (can be toggled at runtime via markers) |
| `messageTemplate` | string | see below | Poke message template. Placeholders: `{seconds}` = current active poke interval in seconds (the timer fires on expiry, so the silent duration at trigger time equals the interval - the default template names it as the interval so the model can answer "what's the interval now"); `{sessionID}` session ID; `{project}` project path |
| `enableMarker` | string | `[Poke On]` | Enable marker. First-line appearance in a model reply enables poking |
| `disableMarker` | string | `[Poke Off]` | Disable marker. First-line appearance disables poking |
| `enablePredictorMarker` | string | `[Predictor On]` | Enable adaptive-interval marker. First-line appearance enables per-session prediction (the next poke evaluates complexity and adjusts the interval) |
| `disablePredictorMarker` | string | `[Predictor Off]` | Disable adaptive-interval marker. First-line appearance disables per-session prediction (the current interval value is kept) |
| `protocol` | string | see below | Poke-control protocol injected into sessions. Placeholders: `{disableMarker}`/`{enableMarker}`/`{disablePredictorMarker}`/`{enablePredictorMarker}` (replaced with actual marker values at runtime). Note: the "[Remind: N unit]" wording is matched by a hardcoded bilingual regex - keeping the default format is recommended |
| `restartNotification` | string | see below | Synthetic message injected after a plugin restart. Placeholders: `{enabled}` "on"/"off", `{interval}` seconds, `{predictor}` "on"/"off" (default predicted-interval state) |
| `predictor.enabled` | boolean | `false` | Enable adaptive interval: before each poke, a throwaway temp session evaluates the recent conversation complexity and auto-adjusts the reminder interval |
| `predictor.maxMessages` | number | `6` | Number of most recent user messages used for complexity evaluation |
| `predictor.agent` | string | `""` | Agent used for complexity evaluation. Empty = default agent; non-empty = override (e.g. `"plan"`) |
| `predictor.model` | string | `""` | Model used for evaluation, format `"provider/model"` (e.g. `"anthropic/claude-..."`). Empty = follow the session's latest real user message model; non-empty = override. Invalid format (no `/`) silently falls back to the main session model |
| `predictor.timeoutMs` | number | `15000` | Prediction timeout (ms). On timeout the prediction is abandoned and poking continues on the fixed interval (the next prediction is unaffected) |
| `predictor.prompt` | string | see below | Prediction prompt, injected via `body.system` into the temp session (appended after the agent prompt) |
| `predictor.denyTools` | string[] | see below | Tools denied to the prediction temp session (permission keys). `edit` covers edit/write/apply_patch; `mcp__*` wildcards all MCP tools. Empty array = no tool restriction (original behavior) |
| `logging.enabled` | boolean | `true` | Master switch for the run log |
| `logging.level` | string | `"info"` | Log level: `debug` (full) / `info` (key actions) / `warn` / `error`. `debug` additionally includes the event stream, raw `text.complete` output, and state transitions |
| `logging.file` | string | `"logs/opencode-idle-poke.log"` | Log file path. **Relative paths are resolved against the config file's directory** (globally `~/.config/opencode/logs/opencode-idle-poke.log`, portable across users, no hardcoded username); absolute paths are also allowed. Empty string = no log file. Files over 10MB are deleted and recreated |

Default `messageTemplate`:

```
[Idle reminder] You have been silent for about {seconds} seconds in session {project} ({sessionID}) - the current active idle-poke interval. If there is unfinished work, pending questions, or anything worth discussing, proactively ask the user; otherwise just briefly say you are waiting and do not spam. For this reply, do NOT read or modify any files, and do NOT run any commands or tools; respond based on the existing conversation only. Reply in the same language the user has been using. After this, follow the user's instructions normally.
```

**About the interval annotation**: at poke trigger, `{seconds}` takes the active interval value (`s.delayMs ?? idleMs`); the timer fires when it expires, so the silent duration at trigger time equals the interval. The default template names it as "the current active idle-poke interval" so the model can directly read "what's the interval now" from context. Known limitation: when `predictor.enabled: true`, the prediction updates `s.delayMs` AFTER `{seconds}` is captured, so the first poke after a prediction still labels the old interval; the new value shows on the next round.

**About the "no file/tool" hint**: the default template includes "For this reply, do NOT read or modify any files, and do NOT run any commands or tools...". This is **belt-and-suspenders**. When the poking agent is `plan` (no file tools by default) or another restricted agent, the hint is a harmless fallback; when using `build` or a custom tool-equipped agent, the hint constrains the model's behavior. Users may edit or remove it as needed.

Default `restartNotification`:

```
[System notification] opencode-idle-poke plugin restarted; poke settings have been reset to defaults (poke {enabled}, interval {interval}s, model-predicted interval {predictor}).
```

**About the restart notification**: after a plugin restart, on the user's first message a synthetic message is injected into the conversation history telling the LLM the poke settings have been reset to defaults. Because it lives in the history, it takes priority over stale markers, preventing the LLM from being misled by old on/off/interval/predictor markers. `{predictor}` reflects the post-restart default prediction state (`predictor.enabled`).

Default `protocol`:

```
If the user asks to stop the proactive idle-poke, write exactly '{disableMarker}' as the first line of your reply; if they ask to resume it, write '{enableMarker}' as the first line. If the user asks to adjust the reminder interval (e.g. 'remind me again in 5 minutes'), write exactly '[Remind: N unit]' as the first line, where N is a number and unit can be seconds/minutes/hours (or s/m/h; omitted means seconds). If the user asks to disable or enable the model-predicted interval, write '{disablePredictorMarker}'/'{enablePredictorMarker}' as the first line. Reply in the same language the user is using, then answer normally.
```

**About the protocol**: the text is injected into the session system prompt via `experimental.chat.system.transform`. Placeholders `{disableMarker}`/`{enableMarker}`/`{disablePredictorMarker}`/`{enablePredictorMarker}` are replaced at runtime with the actual marker values. If a user customizes the markers or the wording, marker detection still works against the actual values (predictor markers are whole-line matched against config values, not hardcoded); however the "[Remind: N unit]" wording is matched by a hardcoded bilingual regex - keeping the default format is recommended. The Chinese form `〔提醒间隔=N单位〕` is also accepted.

## Runtime markers (output on the FIRST line of a model reply)

- Disable poking: `[Poke Off]`
- Enable poking: `[Poke On]`
- Adjust interval: `[Remind: 5 minutes]` (number + optional unit seconds/minutes/hours or s/m/h, omitted = seconds; valid range 20s ~ 24h, out of range ignored). The Chinese form `〔提醒间隔=5分钟〕` is also matched (bilingual regex)
- Disable model-predicted interval: `[Predictor Off]` (per-session; the current interval value is kept, and `[Remind: ...]` still works)
- Enable model-predicted interval: `[Predictor On]` (per-session; the next poke evaluates complexity and adjusts the interval; the poke itself still fires on the old interval - "half a beat" behind)

Markers must be on the reply's **first line** (the protocol requires it); the plugin scans the first 5 lines as a fallback buffer.

## Adaptive interval (predictor)

Two ways to enable (complementary): global `predictor.enabled: true` (all sessions default on after a restart); or per-session via the marker `[Predictor On]` (resets to the default on restart). Disabling likewise: global off + per-session `[Predictor Off]`.

Before each poke (when the session's prediction switch is on):
1. Take the session's most recent `maxMessages` (default 6) real user messages (synthetic messages filtered out);
2. Evaluate complexity in a throwaway temp session: default agent (when `predictor.agent` is empty) or the specified agent, inject `predictor.prompt` (via `body.system`, appended after the agent prompt), and restrict tools per the deny list;
3. Parse the interval marker in its reply (suggested tiers: simple 3 minutes / medium 10 minutes / complex 30 minutes); if in the valid range, update the session's interval (effective on the next poke), otherwise keep the old interval;
4. The temp session is deleted after use.

Model used for evaluation: default = the model of the session's latest real user message (captured by the `chat.message` hook), same as the main conversation; it can be overridden with `predictor.model`. Evaluation is protected by `predictor.timeoutMs` (default 15s); a timeout or any error (session creation failure, missing reply, parse failure, default agent unavailable) silently falls back to the fixed interval without affecting the poke.

**About tool restriction (denyTools)**: deny intercepts at tool **call time**, it does not hide tools - the model still "sees" the tools but calls are rejected. This is an SDK limitation (permissions cannot be set at session creation; only runtime `tools` rules can be passed at prompt time). `predictor.prompt` includes a "no tools" hint as belt-and-suspenders. `denyTools: []` means no `tools` field is passed, restoring default tool permissions.

**About the default agent**: when no `agent` is passed, opencode uses `agents.defaultInfo()` - the configured `default_agent` if set, otherwise the first visible non-subagent agent (usually `build`). If the default agent cannot do prediction, the prediction silently fails and falls back to the fixed interval; poking is unaffected.

No evaluation happens when poking is off (`s.enabled=false`) or the session's prediction switch is off (`s.predictorEnabled=false`). Related log lines: `predictor: interval updated` (info, new interval adopted), `marker: predictor disabled/enabled` (info, marker toggle), `predictor: no valid marker` / `predictor skipped (no model|empty excerpt)` (debug), `predictor failed` (warn).

## Log file format

One line per entry: `[UTC time] [LEVEL] message {extra-field JSON}`

Example:

```
[2026-08-04T08:00:00.000Z] [INFO] plugin initialized {"idleMs":60000,"requireEngagement":true,"enabled":true,"loggingLevel":"info","logFile":"logs/opencode-idle-poke.log"}
[2026-08-04T08:01:00.000Z] [INFO] idle timer set {"sessionID":"ses_xxx","delayMs":60000}
[2026-08-04T08:01:00.000Z] [INFO] poke sent {"sessionID":"ses_xxx","delayMs":60000}
```

Actual log location (relative path): `~/.config/opencode/logs/opencode-idle-poke.log`.

---

# opencode-idle-poke 插件配置说明

配置文件：`~/.config/opencode/opencode-idle-poke.json`（JSON 格式，不支持注释；缺失或解析失败时使用默认值）

| 字段 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| `idleMs` | number | `60000` | 空闲判定时间（毫秒）。用户无输入达到该时长后触发主动搭话 |
| `requireEngagement` | boolean | `true` | 是否要求会话至少有一次用户真实输入后才开始空闲检测 |
| `enabled` | boolean | `true` | 插件启动时的默认开关状态（运行时可用标记切换） |
| `messageTemplate` | string | 见下方模板 | 主动搭话提示模板。占位符：`{seconds}` 当前主动搭话间隔（秒）——定时器到期即触发，触发瞬间已静默时长等于该间隔，默认模板将其标注为间隔，便于模型回答"现在间隔多少"；`{sessionID}` 会话 ID；`{project}` 项目路径 |
| `enableMarker` | string | `[Poke On]` | 开启标记。模型回复第一行出现即开启主动搭话 |
| `disableMarker` | string | `[Poke Off]` | 关闭标记。模型回复第一行出现即关闭主动搭话 |
| `enablePredictorMarker` | string | `[Predictor On]` | 打开模型预测间隔标记。模型回复第一行出现即逐会话启用自适应间隔（下一次搭话时评估复杂度并修改间隔） |
| `disablePredictorMarker` | string | `[Predictor Off]` | 关闭模型预测间隔标记。模型回复第一行出现即逐会话禁用自适应间隔（当前间隔值保持不变） |
| `protocol` | string | 见下方模板 | 注入会话的搭话控制协议。占位符：`{disableMarker}`/`{enableMarker}`/`{disablePredictorMarker}`/`{enablePredictorMarker}`（运行时替换为标记实际值）。注意其中"[Remind: N unit]"的措辞由检测正则硬编码（中英兼容），建议保持默认格式 |
| `restartNotification` | string | 见下方模板 | 插件重启后注入的 synthetic 消息模板。占位符：`{enabled}` "on"/"off"、`{interval}` 秒数、`{predictor}` "on"/"off"（模型预测间隔默认状态） |
| `predictor.enabled` | boolean | `false` | 是否启用"自适应间隔"：搭话前用一次性临时会话评估最近对话复杂度，自动调整提醒间隔 |
| `predictor.maxMessages` | number | `6` | 参与复杂度评估的最近用户消息条数 |
| `predictor.agent` | string | `""` | 用于复杂度评估的代理名。空字符串 = 用默认代理；非空 = 覆盖指定（如 `"plan"`） |
| `predictor.model` | string | `""` | 用于复杂度评估的模型，格式 `"provider/model"`（如 `"anthropic/claude-..."`）。空字符串 = 跟随该会话最近真实用户消息所用模型；非空 = 覆盖。格式非法（无 `/`）时静默回退主会话模型 |
| `predictor.timeoutMs` | number | `15000` | 预测超时毫秒数。超过后放弃本次预测，静默回退固定间隔照常搭话（不影响下次预测） |
| `predictor.prompt` | string | 见下方模板 | 预测提示，经 `body.system` 注入临时会话，追加在代理 prompt 之后 |
| `predictor.denyTools` | string[] | 见下方清单 | 预测子会话禁止使用的工具（权限键）。`edit` 管 edit/write/apply_patch，`mcp__*` 通配全部 MCP 工具。置空数组 = 不设任何工具限制（保持原行为） |
| `logging.enabled` | boolean | `true` | 运行日志总开关 |
| `logging.level` | string | `"info"` | 日志级别，可选：`debug`（全量）/ `info`（关键动作）/ `warn` / `error`。`debug` 额外包含事件流、text.complete 原文、状态流转 |
| `logging.file` | string | `"logs/opencode-idle-poke.log"` | 日志文件路径。**相对路径按配置文件所在目录解析**（全局下即 `~/.config/opencode/logs/opencode-idle-poke.log`，任何用户可移植，不依赖具体用户名）；也可写绝对路径。空字符串表示不写日志文件。文件超过 10MB 会自动整体删除并重建 |

默认 `messageTemplate`：

```
[Idle reminder] You have been silent for about {seconds} seconds in session {project} ({sessionID}) - the current active idle-poke interval. If there is unfinished work, pending questions, or anything worth discussing, proactively ask the user; otherwise just briefly say you are waiting and do not spam. For this reply, do NOT read or modify any files, and do NOT run any commands or tools; respond based on the existing conversation only. Reply in the same language the user has been using. After this, follow the user's instructions normally.
```

**关于间隔标注**：poke 触发时 `{seconds}` 的值取自当次生效间隔（`s.delayMs ?? idleMs`），定时器到期即触发，故触发瞬间已静默时长等于当前间隔。默认模板把它点名为"当前主动搭话间隔"，模型被问"现在间隔多少"时可直接从上下文读出。已知限制：`predictor.enabled: true` 时，预测结果在 `{seconds}` 捕获之后才更新 `s.delayMs`，因此预测后第一条搭话仍标注旧间隔，下一轮才反映新值。

**关于"勿读写文件"的提示**：默认模板含 "For this reply, do NOT read or modify any files, and do NOT run any commands or tools..."。该提示作为**双重保险**保留；当搭话使用的代理为 `plan`（默认无文件工具）或其他受限代理时，提示可视为无害兜底；若使用 `build` 或自定义带工具的代理，提示会约束模型行为。用户可按需修改或移除该段。

默认 `restartNotification`：

```
[System notification] opencode-idle-poke plugin restarted; poke settings have been reset to defaults (poke {enabled}, interval {interval}s, model-predicted interval {predictor}).
```

**关于重启通知**：插件重启后，会在用户首次发消息时注入一条 synthetic 消息到对话历史，告知 LLM 当前搭话设置已恢复默认值。该消息出现在对话历史中，优先级高于旧标记，确保 LLM 不会被旧的开关/间隔/预测开关标记干扰。`{predictor}` 反映重启后的默认预测状态（即 `predictor.enabled`）。

默认 `protocol`：

```
If the user asks to stop the proactive idle-poke, write exactly '{disableMarker}' as the first line of your reply; if they ask to resume it, write '{enableMarker}' as the first line. If the user asks to adjust the reminder interval (e.g. 'remind me again in 5 minutes'), write exactly '[Remind: N unit]' as the first line, where N is a number and unit can be seconds/minutes/hours (or s/m/h; omitted means seconds). If the user asks to disable or enable the model-predicted interval, write '{disablePredictorMarker}'/'{enablePredictorMarker}' as the first line. Reply in the same language the user is using, then answer normally.
```

**关于协议**：该文本经 `experimental.chat.system.transform` 注入会话系统提示。占位符 `{disableMarker}`/`{enableMarker}`/`{disablePredictorMarker}`/`{enablePredictorMarker}` 运行时替换为标记实际值。若用户自定义四个标记或修改协议措辞，标记检测仍按实际标记值工作（预测标记按配置值整行匹配，非硬编码）；但其中"[Remind: N unit]"的措辞由检测正则硬编码（中英兼容），建议保持默认格式。中文形式 `〔提醒间隔=5分钟〕` 同样可匹配。

## 运行时标记（对话中让模型在回复第一行单独输出）

- 停止搭话：`[Poke Off]`
- 恢复搭话：`[Poke On]`
- 调整间隔：`[Remind: 5 minutes]`（数字 + 可选单位 秒/分钟/小时 或 s/m/h，缺省为秒；有效范围 20 秒 ~ 24 小时，范围外忽略）。中文形式 `〔提醒间隔=5分钟〕` 同样可匹配（正则中英兼容）
- 关闭模型预测间隔：`[Predictor Off]`（逐会话关闭自适应间隔，当前间隔值保持不变，仍可用 `[Remind: ...]` 手动调整）
- 打开模型预测间隔：`[Predictor On]`（逐会话启用自适应间隔，下一次搭话时评估复杂度并修改间隔；搭话本身仍在原间隔触发，"慢半拍"）

标记须放在回复**第一行**（协议已要求）；插件扫描前 5 行作兜底缓冲。

## 自适应间隔（predictor）

开启方式有两种（互为补充）：全局 `predictor.enabled: true`（重启后所有会话默认开启）；或会话内用标记 `[Predictor On]` 单独开启（重启回默认状态）。关闭同理：全局关 + 会话内 `[Predictor Off]`。

每次搭话前（该会话预测开关为开时）会：
1. 取该会话最近 `maxMessages`（默认 6）条真实用户消息（过滤 synthetic）；
2. 在一次性临时子会话中评估复杂度：用默认代理（`predictor.agent` 为空时）或指定代理，注入 `predictor.prompt`（经 `body.system`，追加在代理 prompt 之后），并按其禁止列表限制工具；
3. 解析其回复中的间隔标记（档位参考：简单 3 分钟 / 中等 10 分钟 / 复杂 30 分钟），若在有效范围内则更新该会话的间隔（下次搭话生效），否则保持原间隔；
4. 临时子会话用后即删。

评估所用模型：默认 = 该会话最近一条真实用户消息所用模型（`chat.message` 钩子捕获），与主对话一致；也可用 `predictor.model` 显式覆盖。评估有 `predictor.timeoutMs`（默认 15s）超时保护，超时或任何异常（建会话失败、回复缺失、解析失败、默认代理不可用）都会静默回退到原间隔，不影响本次搭话。

**关于工具限制（denyTools）**：deny 在工具**调用时拦截**，不隐藏工具——模型仍"看得见"工具但调用会被拒绝。这是 SDK 限制（会话创建时无法设置权限，只能在 prompt 时传 `tools` 运行时规则）。`predictor.prompt` 中已含"勿执行工具"的提示作为双重保险。置 `denyTools: []` 即不传 `tools` 字段，恢复默认工具权限。

**关于默认代理**：不传 `agent` 时 opencode 使用 `agents.defaultInfo()`——若配置了 `default_agent` 则用它，否则用第一个可见的非 subagent 代理（通常是 `build`）。若默认代理不可用于预测，预测会静默失败并回退固定间隔，搭话不受影响。

搭话关闭（`s.enabled=false`）或该会话预测开关关闭（`s.predictorEnabled=false`）时不会触发评估。相关日志：`predictor: interval updated`（info，采纳新间隔）、`marker: predictor disabled/enabled`（info，标记切换）、`predictor: no valid marker` / `predictor skipped (no model|empty excerpt)`（debug）、`predictor failed`（warn）。

## 日志文件格式

每行一条：`[UTC时间] [级别] 消息 {额外字段JSON}`

示例：

```
[2026-08-04T08:00:00.000Z] [INFO] plugin initialized {"idleMs":60000,"requireEngagement":true,"enabled":true,"loggingLevel":"info","logFile":"logs/opencode-idle-poke.log"}
[2026-08-04T08:01:00.000Z] [INFO] idle timer set {"sessionID":"ses_xxx","delayMs":60000}
[2026-08-04T08:01:00.000Z] [INFO] poke sent {"sessionID":"ses_xxx","delayMs":60000}
```

日志实际落盘位置（相对路径时）：`~/.config/opencode/logs/opencode-idle-poke.log`。
