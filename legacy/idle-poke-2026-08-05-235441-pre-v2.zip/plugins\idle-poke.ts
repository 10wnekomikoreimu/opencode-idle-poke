import type { Plugin } from "@opencode-ai/plugin"
import { appendFile, mkdir, rm, stat } from "node:fs/promises"
import { dirname, isAbsolute, resolve } from "node:path"

const LOG_LEVELS = { debug: 0, info: 1, warn: 2, error: 3 } as const
type LogLevel = keyof typeof LOG_LEVELS

const DEFAULTS = {
  idleMs: 60_000,
  requireEngagement: true,
  enabled: true,
  messageTemplate:
    "【空闲提示】会话 {project}（{sessionID}）中，用户已 {seconds} 秒未输入。" +
    "如有未完成事项、待确认问题或值得讨论的内容，请主动向用户提问；否则仅简短说明你在等待，不要无意义刷屏。" +
    "本次主动搭话请勿读取或修改任何文件、不要执行任何命令或工具，仅基于已有对话内容回应；之后请按用户指令正常执行。",
  enableMarker: "〔主动搭话已开启〕",
  disableMarker: "〔主动搭话已关闭〕",
  restartNotification:
    "[系统通知] idle-poke 插件已重启，搭话设置已恢复默认值" +
    "（默认{enabled}状态、{interval}秒间隔）。",
  predictor: {
    enabled: false,
    maxMessages: 6,
    agent: "idle-poke-predictor",
  },
  logging: {
    enabled: true,
    level: "info" as LogLevel,
    file: ".opencode/logs/idle-poke.log",
  },
}

const MIN_DELAY_MS = 20_000
const MAX_DELAY_MS = 86_400_000
const MAX_LOG_BYTES = 10 * 1024 * 1024
const DELAY_MARKER_RE = /^〔提醒间隔\s*[=＝：:]\s*(\d+(?:\.\d+)?)\s*(秒|分钟|小时)?〕$/

type Config = typeof DEFAULTS

type SessionState = {
  enabled: boolean
  engaged: boolean
  pendingPoke: boolean
  timer?: ReturnType<typeof setTimeout>
  delayMs?: number
  agent?: string
  model?: { providerID: string; modelID: string }
  dirty?: boolean
  notificationInjected?: boolean
}

function toConfig(raw: unknown): Config {
  const config = { ...DEFAULTS, logging: { ...DEFAULTS.logging }, predictor: { ...DEFAULTS.predictor } }
  if (typeof raw !== "object" || raw === null) return config
  const r = raw as Record<string, unknown>
  if (typeof r.idleMs === "number" && Number.isFinite(r.idleMs) && r.idleMs > 0) config.idleMs = r.idleMs
  if (typeof r.requireEngagement === "boolean") config.requireEngagement = r.requireEngagement
  if (typeof r.enabled === "boolean") config.enabled = r.enabled
  if (typeof r.messageTemplate === "string" && r.messageTemplate.trim()) config.messageTemplate = r.messageTemplate
  if (typeof r.enableMarker === "string" && r.enableMarker.trim()) config.enableMarker = r.enableMarker
  if (typeof r.disableMarker === "string" && r.disableMarker.trim()) config.disableMarker = r.disableMarker
  if (typeof r.restartNotification === "string" && r.restartNotification.trim()) config.restartNotification = r.restartNotification
  const p = (r.predictor ?? {}) as Record<string, unknown>
  if (typeof p.enabled === "boolean") config.predictor.enabled = p.enabled
  if (typeof p.maxMessages === "number" && Number.isFinite(p.maxMessages) && p.maxMessages > 0) config.predictor.maxMessages = Math.floor(p.maxMessages)
  if (typeof p.agent === "string" && p.agent.trim()) config.predictor.agent = p.agent
  const l = (r.logging ?? {}) as Record<string, unknown>
  if (typeof l.enabled === "boolean") config.logging.enabled = l.enabled
  if (typeof l.level === "string" && l.level in LOG_LEVELS) config.logging.level = l.level as LogLevel
  if (typeof l.file === "string") config.logging.file = l.file
  return config
}

async function loadConfig(): Promise<{ config: Config; error?: string }> {
  try {
    const file = Bun.file(resolve(import.meta.dir, "..", "idle-poke.json"))
    if (await file.exists()) {
      const raw: unknown = await file.json()
      return { config: toConfig(raw) }
    }
  } catch (e) {
    return { config: toConfig(undefined), error: e instanceof Error ? e.message : String(e) }
  }
  return { config: toConfig(undefined) }
}

export const IdlePokePlugin: Plugin = async (input) => {
  const { client } = input
  const project = input.directory
  const loaded = await loadConfig()
  const config = loaded.config

  let logQueue: Promise<void> = Promise.resolve()
  const log = (level: LogLevel, message: string, extra?: Record<string, unknown>) => {
    const lg = config.logging
    if (!lg.enabled) return
    if (LOG_LEVELS[level] < LOG_LEVELS[lg.level]) return
    const file = lg.file.trim()
    if (!file) return
    const target = isAbsolute(file) ? file : resolve(project, file)
    const line =
      `[${new Date().toISOString()}] [${level.toUpperCase()}] ${message}` +
      (extra ? " " + JSON.stringify(extra) : "") +
      "\n"
    logQueue = logQueue.then(async () => {
      try {
        await mkdir(dirname(target), { recursive: true })
        const st = await stat(target).catch(() => undefined)
        if (st && st.size > MAX_LOG_BYTES) await rm(target, { force: true })
        await appendFile(target, line, "utf8")
      } catch {}
    })
  }

  if (loaded.error) log("warn", "config load failed, using defaults", { error: loaded.error })
  log("info", "plugin initialized", {
    project,
    idleMs: config.idleMs,
    requireEngagement: config.requireEngagement,
    enabled: config.enabled,
    loggingLevel: config.logging.level,
    logFile: config.logging.file,
  })

  const sessions = new Map<string, SessionState>()
  let lastActive = ""

  const ensure = (sessionID: string): SessionState => {
    let s = sessions.get(sessionID)
    if (!s) {
      s = { enabled: config.enabled, engaged: false, pendingPoke: false }
      sessions.set(sessionID, s)
      log("debug", "session tracked", { sessionID })
    }
    return s
  }

  const clearTimer = (sessionID: string) => {
    const s = sessions.get(sessionID)
    if (s?.timer) {
      clearTimeout(s.timer)
      s.timer = undefined
    }
  }

  const onIdle = (sessionID: string) => {
    if (sessionID !== lastActive) return
    const s = ensure(sessionID)
    if (config.requireEngagement && !s.engaged) return
    if (!s.enabled || s.pendingPoke) return
    clearTimer(sessionID)
    const delay = s.delayMs ?? config.idleMs
    s.timer = setTimeout(() => void poke(sessionID), delay)
    log("info", "idle timer set", { sessionID, delayMs: delay })
  }

  const predictorSessions = new Set<string>()

  const buildExcerpt = async (sessionID: string): Promise<string | undefined> => {
    try {
      const res = await client.session.messages({ path: { id: sessionID } })
      const msgs = res.data
      if (!Array.isArray(msgs)) return undefined
      const texts = msgs
        .filter((m) => m.info.role === "user")
        .flatMap((m) => m.parts)
        .filter(
          (p): p is { type: "text"; text: string } =>
            p.type === "text" && !(p as { synthetic?: boolean }).synthetic
        )
        .map((p) => p.text)
      if (!texts.length) return undefined
      return texts.slice(-config.predictor.maxMessages).join("\n\n")
    } catch {
      return undefined
    }
  }

  const predictInterval = async (sessionID: string): Promise<void> => {
    const s = sessions.get(sessionID)
    if (!s || !config.predictor.enabled) return
    if (!s.model) {
      log("debug", "predictor skipped (no model)", { sessionID })
      return
    }
    const excerpt = await buildExcerpt(sessionID)
    if (!excerpt) {
      log("debug", "predictor skipped (empty excerpt)", { sessionID })
      return
    }
    let subID = ""
    try {
      const created = await client.session.create({ query: { directory: project } })
      subID = created.data.id
      predictorSessions.add(subID)
      const res = await client.session.prompt({
        path: { id: subID },
        body: {
          parts: [{ type: "text", text: excerpt, synthetic: true }],
          agent: config.predictor.agent,
          model: s.model,
        },
      })
      const reply = (res.data.parts ?? [])
        .filter((p) => p.type === "text" && !(p as { synthetic?: boolean }).synthetic)
        .map((p) => (p as { text: string }).text)
        .join("\n")
        .trim()
      const line = reply
        .split("\n")
        .map((l) => l.trim())
        .find((l) => l.match(DELAY_MARKER_RE))
      const m = line ? line.match(DELAY_MARKER_RE) : null
      if (m) {
        const value = Number(m[1])
        const unit = m[2] ?? "秒"
        let ms = value * 1000
        if (unit === "分钟") ms = value * 60_000
        else if (unit === "小时") ms = value * 3_600_000
        if (Number.isFinite(ms) && ms >= MIN_DELAY_MS && ms <= MAX_DELAY_MS) {
          s.delayMs = ms
          log("info", "predictor: interval updated", { sessionID, delayMs: ms })
        } else {
          log("debug", "predictor: out of range", { sessionID, ms })
        }
      } else {
        log("debug", "predictor: no valid marker", { sessionID, reply: reply.slice(0, 200) })
      }
    } catch (e) {
      log("warn", "predictor failed", { sessionID, error: e instanceof Error ? e.message : String(e) })
    } finally {
      if (subID) {
        predictorSessions.delete(subID)
        sessions.delete(subID)
        client.session.delete({ path: { id: subID } }).catch(() => undefined)
      }
    }
  }

  const poke = async (sessionID: string) => {
    const s = sessions.get(sessionID)
    if (!s) return
    s.timer = undefined
    if (sessionID !== lastActive) {
      log("debug", "stale poke skipped", { sessionID, lastActive })
      return
    }
    if (!s.enabled || s.pendingPoke) return
    s.pendingPoke = true
    const pokeMs = s.delayMs ?? config.idleMs
    try {
      if (config.predictor.enabled) {
        await predictInterval(sessionID)
        if (sessionID !== lastActive || !s.pendingPoke || !s.enabled) {
          if (sessionID !== lastActive) s.pendingPoke = false
          return
        }
      }
      const text = config.messageTemplate
        .replaceAll("{seconds}", String(Math.round(pokeMs / 1000)))
        .replaceAll("{sessionID}", sessionID)
        .replaceAll("{project}", project)
      await client.session.prompt({
        path: { id: sessionID },
        body: {
          parts: [{ type: "text", text, synthetic: true }],
          ...(s.agent ? { agent: s.agent } : {}),
        },
      })
      log("info", "poke sent", { sessionID, delayMs: pokeMs })
    } catch (e) {
      s.pendingPoke = false
      log("error", "poke failed", { sessionID, error: e instanceof Error ? e.message : String(e) })
    }
  }

  const protocol =
    "若用户表示希望停止主动搭话，请将你的回复中单独一行写为「" +
    config.disableMarker +
    "」；若表示希望恢复，则单独一行写为「" +
    config.enableMarker +
    "」。若用户要求调整提醒间隔（例如“5分钟后再提醒我”），请将你的回复中单独一行写为「〔提醒间隔=N单位〕」，N 为数字，单位可为 秒/分钟/小时（可省略，缺省为秒）。然后正常回复。"

  return {
    event: async ({ event }) => {
      if (event.type === "session.status") {
        const { sessionID, status } = event.properties
        log("debug", "session.status", { sessionID, status: status.type })
        if (status.type === "busy" || status.type === "retry") clearTimer(sessionID)
        else if (status.type === "idle") onIdle(sessionID)
      } else if (event.type === "session.deleted") {
        const sessionID = event.properties.info.id
        clearTimer(sessionID)
        sessions.delete(sessionID)
        log("debug", "session deleted", { sessionID })
      }
    },
    "chat.message": async (msg, output) => {
      if (predictorSessions.has(msg.sessionID)) return
      if (output.parts.some((p) => (p as { synthetic?: boolean }).synthetic)) return
      const sessionID = msg.sessionID
      const s = ensure(sessionID)
      if (!s.dirty && !s.notificationInjected) {
        s.notificationInjected = true
        const text = config.restartNotification
          .replaceAll("{enabled}", config.enabled ? "开启" : "关闭")
          .replaceAll("{interval}", String(config.idleMs / 1000))
        client.session.prompt({
          path: { id: sessionID },
          body: {
            parts: [{ type: "text", text, synthetic: true }],
          },
        })
        log("info", "restart notification sent", { sessionID })
      }
      if (msg.agent) s.agent = msg.agent
      if (msg.model) s.model = msg.model
      s.engaged = true
      s.pendingPoke = false
      lastActive = sessionID
      clearTimer(sessionID)
      for (const [id, st] of sessions) {
        if (id !== sessionID && st.timer) {
          clearTimeout(st.timer)
          st.timer = undefined
          log("debug", "timer cleared (session switched)", { sessionID: id })
        }
      }
      log("debug", "user message", { sessionID })
    },
    "experimental.chat.system.transform": async ({ sessionID }, output) => {
      if (!sessionID) return
      ensure(sessionID)
      output.system.push(protocol)
    },
    "experimental.text.complete": async ({ sessionID }, output) => {
      const s = sessions.get(sessionID)
      if (!s) return
      const lines = output.text.trim().split("\n").slice(0, 5).map((l) => l.trim())
      log("debug", "text complete", { sessionID, lines })
      const hasDisable = lines.includes(config.disableMarker)
      const hasEnable = lines.includes(config.enableMarker)
      let anyMarker = false
      if (hasDisable) {
        s.enabled = false
        log("info", "marker: disabled", { sessionID })
        anyMarker = true
      } else if (hasEnable) {
        s.enabled = true
        log("info", "marker: enabled", { sessionID })
        anyMarker = true
      }
      for (const line of lines) {
        if (line === config.disableMarker || line === config.enableMarker) continue
        const m = line.match(DELAY_MARKER_RE)
        if (m) {
          const value = Number(m[1])
          const unit = m[2] ?? "秒"
          let ms = value * 1000
          if (unit === "分钟") ms = value * 60_000
          else if (unit === "小时") ms = value * 3_600_000
          if (Number.isFinite(ms) && ms >= MIN_DELAY_MS && ms <= MAX_DELAY_MS) {
            s.delayMs = ms
            log("info", "marker: delay", { sessionID, ms })
            anyMarker = true
          }
        }
      }
      if (anyMarker) s.dirty = true
    },
    dispose: async () => {
      for (const s of sessions.values()) if (s.timer) clearTimeout(s.timer)
      log("debug", "plugin disposed", {})
      await logQueue
    },
  }
}
