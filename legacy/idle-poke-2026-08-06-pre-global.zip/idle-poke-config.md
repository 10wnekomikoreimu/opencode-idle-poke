# idle-poke 插件配置说明

配置文件：`~/.config/opencode/idle-poke.json`（JSON 格式，不支持注释；缺失或解析失败时使用默认值）

| 字段 | 类型 | 默认值 | 说明 |
| --- | --- | --- | --- |
| `idleMs` | number | `60000` | 空闲判定时间（毫秒）。用户无输入达到该时长后触发主动搭话 |
| `requireEngagement` | boolean | `true` | 是否要求会话至少有一次用户真实输入后才开始空闲检测 |
| `enabled` | boolean | `true` | 插件启动时的默认开关状态（运行时可用标记切换） |
| `messageTemplate` | string | 见下方模板 | 主动搭话提示模板。占位符：`{seconds}` 当前主动搭话间隔（秒）——触发瞬间已静默时长即该间隔，默认模板将其标注为间隔，便于模型回答"现在间隔多少"；`{sessionID}` 会话 ID；`{project}` 项目路径 |
| `enableMarker` | string | `〔主动搭话已开启〕` | 开启标记。模型回复第一行出现即开启主动搭话 |
| `disableMarker` | string | `〔主动搭话已关闭〕` | 关闭标记。模型回复第一行出现即关闭主动搭话 |
| `protocol` | string | 见下方模板 | 注入会话的搭话控制协议。占位符：`{disableMarker}`/`{enableMarker}`（运行时替换为标记实际值）。注意其中"〔提醒间隔=N单位〕"的措辞建议保持原样（检测正则硬编码） |
| `restartNotification` | string | 见下方模板 | 插件重启后注入的 synthetic 消息模板。占位符：`{enabled}` "开启"/"关闭"、`{interval}` 秒数 |
| `predictor.enabled` | boolean | `false` | 是否启用"自适应间隔"：搭话前用一次性临时会话评估最近对话复杂度，自动调整提醒间隔 |
| `predictor.maxMessages` | number | `6` | 参与复杂度评估的最近用户消息条数 |
| `predictor.agent` | string | `""` | 用于复杂度评估的代理名。空字符串 = 用默认代理；非空 = 覆盖指定（如 `"plan"`） |
| `predictor.model` | string | `""` | 用于复杂度评估的模型，格式 `"provider/model"`（如 `"anthropic/claude-..."`）。空字符串 = 跟随该会话最近真实用户消息所用模型；非空 = 覆盖。格式非法（无 `/`）时静默回退主会话模型 |
| `predictor.timeoutMs` | number | `15000` | 预测超时毫秒数。超过后放弃本次预测，静默回退固定间隔照常搭话（不影响下次预测） |
| `predictor.prompt` | string | 见下方模板 | 预测提示，经 `body.system` 注入临时会话，追加在代理 prompt 之后 |
| `predictor.denyTools` | string[] | 见下方清单 | 预测子会话禁止使用的工具（权限键）。`edit` 管 edit/write/apply_patch，`mcp__*` 通配全部 MCP 工具。置空数组 = 不设任何工具限制（保持原行为） |
| `logging.enabled` | boolean | `true` | 运行日志总开关 |
| `logging.level` | string | `"info"` | 日志级别，可选：`debug`（全量）/ `info`（关键动作）/ `warn` / `error`。`debug` 额外包含事件流、text.complete 原文、状态流转 |
| `logging.file` | string | `"logs/idle-poke.log"` | 日志文件路径。**相对路径按配置文件所在目录解析**（全局下即 `~/.config/opencode/logs/idle-poke.log`，任何用户可移植，不依赖具体用户名）；也可写绝对路径。空字符串表示不写日志文件。文件超过 10MB 会自动整体删除并重建 |

默认 `messageTemplate`：

```
【空闲提示】会话 {project}（{sessionID}）中，当前主动搭话间隔为 {seconds} 秒（本次触发时用户已静默该时长未输入）。如有未完成事项、待确认问题或值得讨论的内容，请主动向用户提问；否则仅简短说明你在等待，不要无意义刷屏。本次主动搭话请勿读取或修改任何文件、不要执行任何命令或工具，仅基于已有对话内容回应；之后请按用户指令正常执行。
```

**关于间隔标注**：poke 触发时 `{seconds}` 的值取自当次生效间隔（`s.delayMs ?? idleMs`），定时器到期即触发，故触发瞬间已静默时长≈当前间隔。默认模板把它点名为"当前主动搭话间隔"，模型被问"现在间隔多少"时可直接从上下文读出。已知限制：`predictor.enabled: true` 时，预测结果在 `{seconds}` 捕获之后才更新 `s.delayMs`，因此预测后第一条搭话仍标注旧间隔，下一轮才反映新值。

**关于"勿读写文件"的提示**：默认模板含 "本次主动搭话请勿读取或修改任何文件..."。该提示作为**双重保险**保留；当搭话使用的代理为 `plan`（默认无文件工具）或其他受限代理时，提示可视为无害兜底；若使用 `build` 或自定义带工具的代理，提示会约束模型行为。用户可按需修改或移除该段。

默认 `restartNotification`：

```
[系统通知] idle-poke 插件已重启，搭话设置已恢复默认值（默认{enabled}状态、{interval}秒间隔）。
```

**关于重启通知**：插件重启后，会在用户首次发消息时注入一条 synthetic 消息到对话历史，告知 LLM 当前搭话设置已恢复默认值。该消息出现在对话历史中，优先级高于旧标记，确保 LLM 不会被旧的开关/间隔标记干扰。

默认 `protocol`：

```
若用户表示希望停止主动搭话，请将你的回复中第一行写为「{disableMarker}」；若表示希望恢复，则第一行写为「{enableMarker}」。若用户要求调整提醒间隔（例如“5分钟后再提醒我”），请将回复中第一行写为「〔提醒间隔=N单位〕」，N 为数字，单位可为 秒/分钟/小时（可省略，缺省为秒）。然后正常回复。
```

**关于协议**：该文本经 `experimental.chat.system.transform` 注入会话系统提示。占位符 `{disableMarker}`/`{enableMarker}` 运行时替换为标记实际值。若用户自定义 `enableMarker`/`disableMarker` 或修改协议措辞，标记检测仍按实际标记值工作；但其中"〔提醒间隔=N单位〕"的措辞由检测正则硬编码，建议保持原样。

## 运行时标记（对话中让模型在回复第一行单独输出）

- 停止搭话：`〔主动搭话已关闭〕`
- 恢复搭话：`〔主动搭话已开启〕`
- 调整间隔：`〔提醒间隔=5分钟〕`（数字 + 可选单位 秒/分钟/小时，缺省为秒；有效范围 20 秒 ~ 24 小时，范围外忽略）

标记须放在回复**第一行**（协议已要求）；插件扫描前 5 行作兜底缓冲。

## 自适应间隔（predictor）

开启 `predictor.enabled: true` 后，每次搭话前会：
1. 取该会话最近 `maxMessages`（默认 6）条真实用户消息（过滤 synthetic）；
2. 在一次性临时子会话中评估复杂度：用默认代理（`predictor.agent` 为空时）或指定代理，注入 `predictor.prompt`（经 `body.system`，追加在代理 prompt 之后），并按其禁止列表限制工具；
3. 解析其回复中的间隔标记（档位参考：简单 1 分钟 / 中等 2 分钟 / 复杂 5 分钟），若在有效范围内则更新该会话的间隔（下次搭话生效），否则保持原间隔；
4. 临时子会话用后即删。

评估所用模型：默认 = 该会话最近一条真实用户消息所用模型（`chat.message` 钩子捕获），与主对话一致；也可用 `predictor.model` 显式覆盖。评估有 `predictor.timeoutMs`（默认 15s）超时保护，超时或任何异常（建会话失败、回复缺失、解析失败、默认代理不可用）都会静默回退到原间隔，不影响本次搭话。

**关于工具限制（denyTools）**：deny 在工具**调用时拦截**，不隐藏工具——模型仍"看得见"工具但调用会被拒绝。这是 SDK 限制（会话创建时无法设置权限，只能在 prompt 时传 `tools` 运行时规则）。`predictor.prompt` 中已含"勿执行工具"的提示作为双重保险。置 `denyTools: []` 即不传 `tools` 字段，恢复默认工具权限。

**关于默认代理**：不传 `agent` 时 opencode 使用 `agents.defaultInfo()`——若配置了 `default_agent` 则用它，否则用第一个可见的非 subagent 代理（通常是 `build`）。若默认代理不可用于预测，预测会静默失败并回退固定间隔，搭话不受影响。

搭话关闭（`s.enabled=false`）时不会触发评估。相关日志：`predictor: interval updated`（info，采纳新间隔）、`predictor: no valid marker` / `predictor skipped (no model|empty excerpt)`（debug）、`predictor failed`（warn）。

## 日志文件格式

每行一条：`[UTC时间] [级别] 消息 {额外字段JSON}`

示例：

```
[2026-08-04T08:00:00.000Z] [INFO] plugin initialized {"idleMs":60000,"requireEngagement":true,"enabled":true,"loggingLevel":"info","logFile":"logs/idle-poke.log"}
[2026-08-04T08:01:00.000Z] [INFO] idle timer set {"sessionID":"ses_xxx","delayMs":60000}
[2026-08-04T08:01:00.000Z] [INFO] poke sent {"sessionID":"ses_xxx","delayMs":60000}
```

日志实际落盘位置（相对路径时）：`~/.config/opencode/logs/idle-poke.log`。
