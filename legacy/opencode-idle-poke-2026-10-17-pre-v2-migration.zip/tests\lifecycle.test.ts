import { describe, it, expect, beforeEach, afterEach, vi } from "vitest"
import {
  makeClient,
  makePlugin,
  userMessage,
  idleEvent,
  busyEvent,
  createdEvent,
  updatedEvent,
  setConfigFixture,
  resetConfig,
  pokes,
  notifications,
} from "./helpers"

describe("plugin lifecycle", () => {
  beforeEach(() => {
    vi.useFakeTimers()
    setConfigFixture({ logging: { enabled: false } })
  })

  afterEach(() => {
    vi.useRealTimers()
    resetConfig()
  })

  it("initializes and returns a hooks object", async () => {
    const { client } = makeClient()
    const p = await makePlugin(client)
    expect(typeof p.event).toBe("function")
    expect(typeof p["chat.message"]).toBe("function")
    expect(typeof p["experimental.chat.system.transform"]).toBe("function")
    expect(typeof p["experimental.text.complete"]).toBe("function")
    expect(typeof p.dispose).toBe("function")
    await p.dispose()
  })

  it("does not poke when idle fires before any user message", async () => {
    const { client, calls } = makeClient()
    const p = await makePlugin(client)
    await p.event(idleEvent("s1"))
    await vi.advanceTimersByTimeAsync(120_000)
    expect(pokes(calls)).toHaveLength(0)
    await p.dispose()
  })

  it("sends one poke after user message + idle, preserving the agent", async () => {
    const { client, calls } = makeClient()
    const p = await makePlugin(client)
    const { input, output } = userMessage("s1", { agent: "plan" })
    await p["chat.message"](input, output)
    await p.event(idleEvent("s1"))
    await vi.advanceTimersByTimeAsync(60_000)
    const poke = pokes(calls)[0]
    expect(poke).toBeTruthy()
    expect(poke.path.id).toBe("s1")
    expect(poke.body.agent).toBe("plan")
    expect(poke.body.parts[0].synthetic).toBe(true)
    expect(poke.body.parts[0].text).toContain("You have been silent for about 60 seconds")
    expect(poke.body.parts[0].text).toContain("s1")
    await p.dispose()
  })

  it("renders messageTemplate placeholders for seconds/sessionID/project", async () => {
    setConfigFixture({
      idleMs: 90_000,
      messageTemplate: "[T] {seconds}s {sessionID} {project}",
      logging: { enabled: false },
    })
    const { client, calls } = makeClient()
    const p = await makePlugin(client, "C:\\users\\demo\\proj")
    const { input, output } = userMessage("abc")
    await p["chat.message"](input, output)
    await p.event(idleEvent("abc"))
    await vi.advanceTimersByTimeAsync(90_000)
    const poke = pokes(calls)[0]
    expect(poke.body.parts[0].text).toBe("[T] 90s abc C:\\users\\demo\\proj")
    await p.dispose()
  })

  it("does not re-poke while pendingPoke is set", async () => {
    const { client, calls } = makeClient()
    const p = await makePlugin(client)
    const { input, output } = userMessage("s1")
    await p["chat.message"](input, output)
    await p.event(idleEvent("s1"))
    await vi.advanceTimersByTimeAsync(60_000)
    expect(pokes(calls)).toHaveLength(1)
    await p.event(idleEvent("s1"))
    await vi.advanceTimersByTimeAsync(120_000)
    expect(pokes(calls)).toHaveLength(1)
    await p.dispose()
  })

  it("resets pendingPoke on the next real user message", async () => {
    const { client, calls } = makeClient()
    const p = await makePlugin(client)
    let msg = userMessage("s1")
    await p["chat.message"](msg.input, msg.output)
    await p.event(idleEvent("s1"))
    await vi.advanceTimersByTimeAsync(60_000)
    expect(pokes(calls)).toHaveLength(1)
    msg = userMessage("s1")
    await p["chat.message"](msg.input, msg.output)
    await p.event(idleEvent("s1"))
    await vi.advanceTimersByTimeAsync(60_000)
    expect(pokes(calls)).toHaveLength(2)
    await p.dispose()
  })

  it("clears the idle timer on busy status", async () => {
    const { client, calls } = makeClient()
    const p = await makePlugin(client)
    const { input, output } = userMessage("s1")
    await p["chat.message"](input, output)
    await p.event(idleEvent("s1"))
    await p.event(busyEvent("s1"))
    await vi.advanceTimersByTimeAsync(120_000)
    expect(pokes(calls)).toHaveLength(0)
    await p.dispose()
  })

  it("dispose clears pending timers", async () => {
    const { client, calls } = makeClient()
    const p = await makePlugin(client)
    const { input, output } = userMessage("s1")
    await p["chat.message"](input, output)
    await p.event(idleEvent("s1"))
    await p.dispose()
    await vi.advanceTimersByTimeAsync(120_000)
    expect(pokes(calls)).toHaveLength(0)
  })

  it("synthetic user messages are ignored", async () => {
    const { client, calls } = makeClient()
    const p = await makePlugin(client)
    const msg = userMessage("s1", { synthetic: true })
    await p["chat.message"](msg.input, msg.output)
    await p.event(idleEvent("s1"))
    await vi.advanceTimersByTimeAsync(120_000)
    expect(pokes(calls)).toHaveLength(0)
    expect(notifications(calls)).toHaveLength(0)
    await p.dispose()
  })

  it("chat.message ignores predictor sub-sessions", async () => {
    setConfigFixture({
      idleMs: 60_000,
      predictor: { enabled: true, maxMessages: 6, agent: "", model: "", timeoutMs: 15_000, prompt: "assess", denyTools: [] },
      logging: { enabled: false },
    })
    const { client, calls } = makeClient()
    client.setMessages([{ info: { role: "user" }, parts: [{ type: "text", text: "q", synthetic: false }] }])
    let release: (() => void) | undefined
    client.setPromptHandler(async (arg: any) => {
      if (arg.path.id.startsWith("sub-")) {
        await new Promise<void>((res) => {
          release = res
        })
        return { data: { parts: [{ type: "text", text: "[Remind: 1 minutes]", synthetic: false }] } }
      }
      return { data: { parts: [] } }
    })
    const p = await makePlugin(client)
    const msg = userMessage("s1", { model: { providerID: "p", modelID: "m" } })
    await p["chat.message"](msg.input, msg.output)
    await p.event(idleEvent("s1"))
    await vi.advanceTimersByTimeAsync(60_000)
    const subID = calls.create[0].id
    expect(release).toBeDefined()
    const notifsBefore = notifications(calls).length
    await p["chat.message"]({ sessionID: subID }, { parts: [{ type: "text", text: "ignore me", synthetic: false }] })
    expect(notifications(calls)).toHaveLength(notifsBefore)
    release!()
    await vi.advanceTimersByTimeAsync(0)
    await p.dispose()
  })

  it("clears the idle timer on retry status", async () => {
    const { client, calls } = makeClient()
    const p = await makePlugin(client)
    const { input, output } = userMessage("s1")
    await p["chat.message"](input, output)
    await p.event(idleEvent("s1"))
    await p.event({
      event: { type: "session.status", properties: { sessionID: "s1", status: { type: "retry" } } },
    })
    await vi.advanceTimersByTimeAsync(120_000)
    expect(pokes(calls)).toHaveLength(0)
    await p.dispose()
  })

  it("ignored session messages do not clear timers, inject notifications, or become lastActive", async () => {
    setConfigFixture({ ignoreSessionTitles: ["opencode-mem capture"], logging: { enabled: false } })
    const { client, calls } = makeClient()
    const p = await makePlugin(client)
    const a = userMessage("s1")
    await p["chat.message"](a.input, a.output)
    await p.event(idleEvent("s1"))
    await p.event(createdEvent("sub-cap", "opencode-mem capture"))
    const b = userMessage("sub-cap")
    await p["chat.message"](b.input, b.output)
    expect(calls.get.map((c) => c.path.id)).not.toContain("sub-cap")
    await vi.advanceTimersByTimeAsync(60_000)
    const poke = pokes(calls)[0]
    expect(poke).toBeTruthy()
    expect(poke.path.id).toBe("s1")
    expect(notifications(calls).every((n) => n.path.id === "s1")).toBe(true)
    await p.dispose()
  })

  it("chat.message falls back to session.get when no title event was seen", async () => {
    setConfigFixture({ ignoreSessionTitles: ["opencode-mem capture"], logging: { enabled: false } })
    const { client, calls } = makeClient()
    client.setTitle("sub-cap", "opencode-mem capture")
    const p = await makePlugin(client)
    const a = userMessage("s1")
    await p["chat.message"](a.input, a.output)
    await p.event(idleEvent("s1"))
    const b = userMessage("sub-cap")
    await p["chat.message"](b.input, b.output)
    expect(calls.get.map((c) => c.path.id)).toContain("sub-cap")
    await vi.advanceTimersByTimeAsync(60_000)
    const poke = pokes(calls)[0]
    expect(poke).toBeTruthy()
    expect(poke.path.id).toBe("s1")
    await p.dispose()
  })

  it("onIdle ignores a session whose title matches after a rename", async () => {
    setConfigFixture({ ignoreSessionTitles: ["opencode-mem capture"], logging: { enabled: false } })
    const { client, calls } = makeClient()
    const p = await makePlugin(client)
    const msg = userMessage("s1")
    await p["chat.message"](msg.input, msg.output)
    await p.event(updatedEvent("s1", "opencode-mem capture"))
    await p.event(idleEvent("s1"))
    await vi.advanceTimersByTimeAsync(120_000)
    expect(pokes(calls)).toHaveLength(0)
    await p.dispose()
  })

  it("a non-matching title still behaves as a normal focus switch", async () => {
    const { client, calls } = makeClient()
    const p = await makePlugin(client)
    const a = userMessage("s1")
    await p["chat.message"](a.input, a.output)
    await p.event(idleEvent("s1"))
    await p.event(createdEvent("s2", "regular conversation"))
    const b = userMessage("s2")
    await p["chat.message"](b.input, b.output)
    await vi.advanceTimersByTimeAsync(120_000)
    expect(pokes(calls)).toHaveLength(0)
    await p.dispose()
  })
})
